RegisterNetEvent("dv:checkPermissionAndWarnAll", function()
    local src = source
    if IsPlayerAceAllowed(src, "command.dvall") then
        TriggerClientEvent("dv:showGlobalWarning", -1)
        Wait(20000)
        TriggerClientEvent("dv:deleteVehiclesClientside", -1)

        TriggerClientEvent('ox_lib:notify', -1, {
            title = 'Cleanup Complete',
            description = 'All vehicles have been removed.',
            type = 'success'
        })
    else
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Permission Denied',
            description = 'You do not have permission to use /dvall.',
            type = 'error'
        })
    end
end)
