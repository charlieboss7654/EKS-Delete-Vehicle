local lib = exports.ox_lib

RegisterCommand("dv", function()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local vehicle = GetVehiclePedIsIn(playerPed, false)

    if vehicle == 0 then
        local vehicles = GetGamePool("CVehicle")
        local closestVeh
        local minDist = 3.0

        for _, v in ipairs(vehicles) do
            local vCoords = GetEntityCoords(v)
            local dist = #(coords - vCoords)
            if dist < minDist and GetPedInVehicleSeat(v, -1) == 0 then
                closestVeh = v
                minDist = dist
            end
        end

        if closestVeh then
            vehicle = closestVeh
        else
            lib:notify({
                title = 'Error',
                description = 'No vehicle nearby to delete.',
                type = 'error'
            })
            return
        end
    end

    if DoesEntityExist(vehicle) then
        NetworkRequestControlOfEntity(vehicle)
        Wait(100)
        DeleteEntity(vehicle)
        lib:notify({
            title = 'Vehicle Deleted',
            description = 'Vehicle successfully deleted.',
            type = 'success'
        })
    end
end, false)

RegisterCommand("dvall", function()
    TriggerServerEvent("dv:checkPermissionAndWarnAll")
end, false)

RegisterNetEvent("dv:showGlobalWarning")
AddEventHandler("dv:showGlobalWarning", function()
    lib:progressBar({
        duration = 20000,
        label = 'vehicles will be deleted in 20 seconds!',
        useWhileDead = true,
        canCancel = false,
        disable = {}
    })
end)


RegisterNetEvent("dv:deleteVehiclesClientside")
AddEventHandler("dv:deleteVehiclesClientside", function()
    local vehicles = GetGamePool("CVehicle")

    for _, vehicle in ipairs(vehicles) do
        if DoesEntityExist(vehicle) and NetworkHasControlOfEntity(vehicle) then
            -- Skip vehicles with a player or ped inside
            if GetPedInVehicleSeat(vehicle, -1) ~= 0 or GetPedInVehicleSeat(vehicle, 0) ~= 0 then
                goto continue
            end

            SetEntityAsMissionEntity(vehicle, true, true)
            DeleteEntity(vehicle)

            if DoesEntityExist(vehicle) then
                DeleteVehicle(vehicle)
            end

            ::continue::
        end
    end
end)
