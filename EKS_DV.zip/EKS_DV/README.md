THIS SCRIPT WAS MADE BY ECHO KILO STUDIOS
CHECK THE LICENCE FOR USAGE RIGHTS

More updates WILL be coming in the future!
Version 1.0

Description:
This is a simple bodycam script that allows users to hear bodycam chimes. 
To config go to the config.lua

THIS SCRIPT WAS MADE BY ECHO KILO STUDIOS
CHECK THE LICENCE FOR USAGE RIGHTS

This is a simple drag and drop script!

Installation Guide:
1. Download EKS_DV
2. Open your server directory
3. Locate your resource folder (scripts folder if you have one also)
4. Drop the EKS_DV file into the resource/script folder
5. Go to your server.cfg and paste the following "EKS_DV"
6. Start the resource and you are good to go - Enjoy!

**Important note - DO NOT CHANGE THE NAME OF THE FOLDER ELSE THE SCRIPT WILL NOT WORK!**
