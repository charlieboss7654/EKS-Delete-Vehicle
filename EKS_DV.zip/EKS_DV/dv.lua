RegisterCommand("dv", function()
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    
    if vehicle ~= 0 then -- Check if the player is in a vehicle
        local driver = GetPedInVehicleSeat(vehicle, -1) -- Get the driver
        
        if driver == playerPed then -- Ensure the player is the driver
            DeleteEntity(vehicle) -- Delete the vehicle
            TriggerEvent('chat:addMessage', {
                args = {"[SYSTEM]", "Vehicle deleted successfully."}
            })
        else
            TriggerEvent('chat:addMessage', {
                args = {"[SYSTEM]", "You must be the driver to delete the vehicle!"}
            })
        end
    else
        TriggerEvent('chat:addMessage', {
            args = {"[SYSTEM]", "You must be in a vehicle to use this command!"}
        })
    end
end, false)
