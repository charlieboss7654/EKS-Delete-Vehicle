fx_version 'cerulean'
game 'gta5'

author 'R.Robertson - Echo Kilo Studios'
description 'Delete Vehicle Command'
version '1.0.0'

client_script 'dv.lua'
